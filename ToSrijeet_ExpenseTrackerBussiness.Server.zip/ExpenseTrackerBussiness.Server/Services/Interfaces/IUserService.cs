using ExpenseTrackerBusiness.Server.Dto.Signup;
using ExpenseTrackerBusiness.Server.DTOs.Signup;
using ExpenseTrackerBusiness.Server.DTOs.Login;
using ExpenseTrackerBusiness.Server.Models;

namespace ExpenseTrackerBusiness.Server.Services.Interfaces
{
    public interface IUserService
    {
        Task<SignupResponce> Signup(SignupRequest dto);
        Task<LoginResponce> Login(LoginRequest dto);
    }
}


