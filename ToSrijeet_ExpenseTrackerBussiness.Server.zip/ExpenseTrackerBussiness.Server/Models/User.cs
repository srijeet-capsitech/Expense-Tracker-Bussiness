﻿//using System.ComponentModel.DataAnnotations;

//namespace ExpenseTrackerBusiness.Server.Models
//{
//    public class User
//    {
//        public string Id { get; set; }

//        public string EmployeeId { get; set; }

//        [Required(ErrorMessage ="Name is required.")]
//        [StringLength(70,MinimumLength =3,ErrorMessage ="Name must be between 3 to 70 characters.")]
//        public string Name { get; set; }

//        [Required(ErrorMessage ="Email is required.")]
//        public string Email { get; set; }

//        [Required(ErrorMessage ="password is required.")]
//        public string Password { get; set; }

//        [Required(ErrorMessage ="phone number is required.")]
//        public string Phone { get; set; }

//        [Required(ErrorMessage ="Role of the user must be defined.")]
//        public string Role { get; set; }

//        [Required(ErrorMessage ="created by is required.")]
//        public string CreatedBy { get; set; }

//        [Required]
//        public string? DepartmentId { get; set; }

//        [Required]
//        public string? OrganisationId { get; set; }  

//        public DateTime UpdatedAt { get; set; }

//        public DateTime DeletedBy { get; set; }


//        public string RefreshToken { get; set; }

//    }
//}


using System;
using System.ComponentModel.DataAnnotations;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace ExpenseTrackerBusiness.Server.Models
{
    public class User
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string Id { get; set; }

        [BsonElement("employeeId")]
        public string EmployeeId { get; set; }

        [Required(ErrorMessage = "Name is required.")]
        [StringLength(70, MinimumLength = 3, ErrorMessage = "Name must be between 3 to 70 characters.")]
        [BsonElement("name")]
        public string Name { get; set; }

        [Required(ErrorMessage = "Email is required.")]
        [BsonElement("email")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Password is required.")]
        [BsonElement("password")]
        public string Password { get; set; }

        [Required(ErrorMessage = "Phone number is required.")]
        [BsonElement("phone")]
        public string Phone { get; set; }

        [Required(ErrorMessage = "Role of the user must be defined.")]
        [BsonElement("role")]
        public string Role { get; set; }

        [Required(ErrorMessage = "Created by is required.")]
        [BsonElement("createdBy")]
        public string CreatedBy { get; set; }

        [Required]
        [BsonElement("departmentId")]
        public string? DepartmentId { get; set; }

        [Required]
        [BsonElement("organisationId")]
        public string? OrganisationId { get; set; }

        [BsonElement("updatedAt")]
        public DateTime UpdatedAt { get; set; }

        [BsonElement("deletedBy")]
        public DateTime DeletedBy { get; set; }

        [BsonElement("refreshToken")]
        public string RefreshToken { get; set; }
    }
}