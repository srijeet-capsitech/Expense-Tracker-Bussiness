﻿namespace ExpenseTrackerBussiness.Server.Models
{
    public class MongoDbSetting
    {
    }
}
