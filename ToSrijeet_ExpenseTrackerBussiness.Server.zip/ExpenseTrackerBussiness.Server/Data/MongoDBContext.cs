﻿namespace ExpenseTrackerBusiness.Server.Data
{
    public class MongoDbContext
    {
    }
}
